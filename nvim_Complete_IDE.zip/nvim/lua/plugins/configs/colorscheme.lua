-- ~/.config/nvim/lua/custom/colorscheme.lua

-- Your snippet starts here ↓
local p = {
  foreground = "#d8dadf",
  cursor = "#cccccc",
  color0 = "#282c34",
  ...
  color16 = "#3d424c",
  selection_background = "#979eab",

  highlight_high = "#3d424c",
  love = "#e06c75",
}

local groups = {
  border = p.color16,
  error = p.color1,
  hint = p.color4,
  info = p.color2,
  ok = p.color2,
  panel = p.color8,
  success = p.color2,
  warning = p.color3,

  git_change = p.color3,
  git_add = p.color2,
  git_delete = p.color1,
}

local function darken(hex, percentage)
  ...
end

local function brighten(hex, percentage)
  ...
end

-- Terminal colors
vim.g.terminal_color_0  = p.color0
vim.g.terminal_color_1  = p.color1
...
vim.g.terminal_color_15 = p.color15

-- Highlights
local highlights = {
  Normal = { fg = p.foreground, bg = p.color0 },
  ...
  ["@property.yaml"] = { fg = p.foreground },
}

-- Apply highlights
for group, highlight in pairs(highlights) do
  vim.api.nvim_set_hl(0, group, highlight)
end


