-- formatter.lua
-- This file configures formatter.nvim to format files for multiple languages

-- Utility functions for creating formatter configurations
local util = require("formatter.util")

require("formatter").setup({
  logging = true,                   -- Enable logging for debugging purposes
  log_level = vim.log.levels.WARN,  -- Log level can be set to INFO, WARN, etc.
  filetype = {
    -- Lua: Using the default stylua formatter from formatter.nvim
    lua = {
      require("formatter.filetypes.lua").stylua,
      -- You can also add a custom configuration, for example:
      function()
        -- Skip formatting for a special file if needed
        if util.get_current_buffer_file_name() == "special.lua" then
          return nil
        end
        return {
          exe = "stylua",
          args = {
            "--search-parent-directories",
            "--stdin-filepath",
            util.escape_path(util.get_current_buffer_file_path()),
            "--",
            "-",
          },
          stdin = true,
        }
      end,
    },

    -- Python: Using black and isort as formatters
    python = {
      require("formatter.filetypes.python").black,
      function()
        return {
          exe = "isort",
          args = {
            "--stdout",
            util.escape_path(util.get_current_buffer_file_path()),
          },
          stdin = true,
        }
      end,
    },

    -- JavaScript and TypeScript: Using prettierd
    javascript = {
      require("formatter.filetypes.javascript").prettierd,
    },
    typescript = {
      require("formatter.filetypes.typescript").prettierd,
    },

    -- HTML, CSS, JSON: Also using prettierd
    html = {
      require("formatter.filetypes.html").prettierd,
    },
    css = {
      require("formatter.filetypes.css").prettierd,
    },
    json = {
      require("formatter.filetypes.json").prettierd,
    },

    -- Go: Using gofmt
    go = {
      function()
        return {
          exe = "gofmt",
          args = {},
          stdin = true,
        }
      end,
    },

    -- C: Using clang-format
    c = {
      function()
        return {
          exe = "clang-format",
          args = {},
          stdin = true,
        }
      end,
    },

    -- C++: Using clang-format (filetype is usually "cpp")
    cpp = {
      function()
        return {
          exe = "clang-format",
          args = {},
          stdin = true,
        }
      end,
    },

    -- Rust: Using rustfmt
    rust = {
      function()
        return {
          exe = "rustfmt",
          args = {"--emit=stdout"},
          stdin = true,
        }
      end,
    },

    -- Default formatter for all filetypes: remove trailing whitespace
    ["*"] = {
      require("formatter.filetypes.any").remove_trailing_whitespace,
    },
  },
})

-- Optional key mappings to trigger formatting commands
vim.api.nvim_set_keymap("n", "<leader>f", ":Format<CR>", { noremap = true, silent = true })
vim.api.nvim_set_keymap("n", "<leader>F", ":FormatWrite<CR>", { noremap = true, silent = true })

-- Optional: Automatically format on save for all filetypes
vim.api.nvim_exec([[
  augroup FormatAutogroup
    autocmd!
    autocmd BufWritePost * FormatWrite
  augroup END
]], true)

