require("conform").setup({
  formatters_by_ft = {
    lua = { "stylua" },
    python = { "isort", "black" },
    rust = { "rustfmt", lsp_format = "fallback" }, -- Uses rustfmt, or falls back to rust analyzer via LSP
    javascript = { "prettierd", "prettier", stop_after_first = true },
    go = { "gofmt" },           -- For Go files
    c = { "clang-format" },     -- For C files
    cpp = { "clang-format" },   -- For C++ files (typically filetype is "cpp")
    -- If your filetype for C++ is "c++", you could alternatively add:
    -- ["c++"] = { "clang-format" },
   },
})


