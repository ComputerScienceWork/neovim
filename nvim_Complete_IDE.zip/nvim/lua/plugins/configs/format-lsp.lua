-- First, set up lsp-format
require("lsp-format").setup {}

-- Create a common on_attach function that activates lsp-format
local on_attach = function(client, bufnr)
  require("lsp-format").on_attach(client, bufnr)
  -- You can add any additional custom on_attach logic here
end

-- Require lspconfig for configuring language servers
local lspconfig = require("lspconfig")

-- Setup for Go (gopls)
lspconfig.gopls.setup { on_attach = on_attach }

-- Setup for C/C++ (clangd works for both C and C++)
lspconfig.clangd.setup { on_attach = on_attach }

-- Setup for Rust (rust_analyzer)
lspconfig.rust_analyzer.setup { on_attach = on_attach }

-- Setup for Python (pyright), as an example for other languages
lspconfig.pyright.setup { on_attach = on_attach }

-- Add additional LSP server setups as needed:
-- lspconfig.some_other_language_server.setup { on_attach = on_attach }

