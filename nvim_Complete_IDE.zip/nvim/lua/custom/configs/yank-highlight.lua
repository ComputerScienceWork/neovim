-- File: lua/custom/configs/yank-highlight.lua

vim.api.nvim_create_autocmd("TextYankPost", {
  pattern = "*",
  callback = function()
    vim.highlight.on_yank {
      higroup = "Visual", -- You can change this to a custom group
      timeout = 150, -- milliseconds
    }
  end,
})
