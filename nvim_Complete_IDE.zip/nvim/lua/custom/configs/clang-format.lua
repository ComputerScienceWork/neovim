return {
  "stevearc/conform.nvim",
  config = function()
    require("conform").setup {
      formatters_by_ft = {
        lua = { "stylua" },
        python = { "isort", "black" },
        rust = { "rustfmt" },
        javascript = { { "prettierd", "prettier" } },
        c = { "clang_format" },
        cpp = { "clang_format" }, -- Filetype is "cpp", not "c_plus_plus"
      },
      formatters = {
        rustfmt = {
          command = "rustfmt",
          args = { "--edition", "2021" },
          stdin = true,
        },
        clang_format = {
          command = "clang-format",
          args = { "-style=file", "-assume-filename=%:p" }, -- Use project's .clang-format
          stdin = true,
        },
      },
    }
  end,
}
