return {
require("conform").setup({
  -- Define formatters for each filetype
  formatters_by_ft = {
    rust   = { "rustfmt", lsp_format = "fallback" },
    go     = { "goimports", "gofmt", stop_after_first = true },
    c      = { "clang-format" },
    cpp    = { "clang-format" },
    lua    = { "stylua" },
    json   = { "prettierd", stop_after_first = true },
    java   = { "google-java-format" },
    -- You can add additional filetypes if needed
  },
  -- Enable format on save
  format_on_save = {
    lsp_format = "fallback",  -- Use LSP formatting if no other formatter is available
    timeout_ms = 500,         -- Timeout for formatting in milliseconds
  },
  log_level = vim.log.levels.ERROR,  -- Log errors only
  notify_on_error = true,            -- Notify if a formatter errors
  notify_no_formatters = true,       -- Notify if no formatter is available
})

-- Optional: If you want to trigger formatting on a specific buffer event (e.g. on write),
-- you can add an autocmd. This is useful if you want more control beyond the built-in format_on_save.
vim.api.nvim_create_autocmd("BufWritePre", {
  pattern = "*",
  callback = function(args)
    require("conform").format({ bufnr = args.buf })
  end,
})
}
