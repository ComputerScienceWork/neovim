local dap = require "dap"

-- 🦀 RUST (using codelldb)
dap.adapters.codelldb = {
  type = "server",
  port = "${port}",
  executable = {
    command = vim.fn.exepath "codelldb",
    args = { "--port", "${port}" },
  },
}
dap.configurations.rust = {
  {
    name = "Launch Rust executable",
    type = "codelldb",
    request = "launch",
    program = function()
      return vim.fn.input("Path to executable: ", vim.fn.getcwd() .. "/target/debug/", "file")
    end,
    cwd = "${workspaceFolder}",
    stopOnEntry = false,
  },
}

-- 🐹 GO (using delve)
dap.adapters.delve = {
  type = "server",
  port = "${port}",
  executable = {
    command = vim.fn.exepath "dlv",
    args = { "dap", "-l", "127.0.0.1:${port}" },
  },
}
dap.configurations.go = {
  {
    type = "delve",
    name = "Debug Go file",
    request = "launch",
    program = "${file}",
  },
}

-- ☕ JAVA (using java-debug)
dap.adapters.java = function(callback)
  -- Java adapter setup might require more tools like nvim-jdtls
  callback {
    type = "server",
    host = "127.0.0.1",
    port = 5005,
  }
end
dap.configurations.java = {
  {
    type = "java",
    request = "attach",
    name = "Attach to JVM",
    hostName = "127.0.0.1",
    port = 5005,
  },
}

-- 🐍 PYTHON (using debugpy)
dap.adapters.python = {
  type = "executable",
  command = vim.fn.exepath "python",
  args = { "-m", "debugpy.adapter" },
}
dap.configurations.python = {
  {
    type = "python",
    request = "launch",
    name = "Launch file",
    program = "${file}",
    pythonPath = function()
      return vim.fn.exepath "python"
    end,
  },
}
