---@type ChadrcConfig
local M = {}

-- Core NVChad Configuration
M.ui = { theme = "oxocarbon" }
M.plugins = "custom.plugins"
M.mappings = require "custom.mappings"

-- Early Load Requirements
vim.defer_fn(function()
  -- Configuration Loaders
  require "custom.autocmds"
  require "custom.runner"
  require "custom.configs.clang-format"
  require "custom.configs.dap"

  -- nvim-ide Panel Group Patch
  local ide_workspace = package.loaded["ide.workspaces.workspace"]
  if ide_workspace and ide_workspace.swap_panel then
    local original_swap_panel = ide_workspace.swap_panel
    ide_workspace.swap_panel = function(self, group)
      if not self.panel_groups[group] then
        vim.schedule(function()
          vim.notify("⚠️ Ignoring missing panel group: " .. group, vim.log.levels.WARN)
        end)
        return
      end
      original_swap_panel(self, group)
    end
  end
end, 50)

-- LSP Configuration
M.lsp = {
  signature = true,

  clangd = {
    on_attach = function(client, bufnr)
      -- Format-on-save setup
      if client.server_capabilities.documentFormattingProvider then
        vim.api.nvim_create_autocmd("BufWritePre", {
          buffer = bufnr,
          callback = function()
            vim.lsp.buf.format { async = false }
          end,
        })
      end

      -- Manual formatting keymap
      local opts = { noremap = true, silent = true, buffer = bufnr }
      vim.keymap.set("n", "<leader>f", vim.lsp.buf.format, opts)
    end,
  },
}

-- C/C++ Execution Configuration
local wezterm_path = "/opt/homebrew/bin/wezterm"

local function compile_and_run()
  local file = vim.api.nvim_buf_get_name(0)
  local filename = vim.fn.fnamemodify(file, ":t")
  local cwd = vim.fn.fnamemodify(file, ":h")
  local ft = vim.bo.filetype

  local output = "/tmp/" .. vim.fn.fnamemodify(filename, ":r")
  local compiler = ft == "c" and "gcc" or "g++"
  local std = ft == "c" and "c17" or "c++20"

  local compile_cmd = table.concat({
    compiler,
    "-g -Wall -Wextra -Werror -pedantic -O0",
    "-std=" .. std,
    "-fstack-protector-all -fsanitize=undefined",
    "-o",
    vim.fn.shellescape(output),
    vim.fn.shellescape(filename),
    "&&",
    vim.fn.shellescape(output),
    "; rm -f",
    vim.fn.shellescape(output),
  }, " ")

  local full_cmd = string.format(
    [[cd %s && echo '\033[1;33m▶ Running: %s\033[0m' && %s]],
    vim.fn.shellescape(cwd),
    filename,
    compile_cmd
  )

  vim.fn.jobstart({
    wezterm_path,
    "start",
    "--always-new-process",
    "zsh",
    "-c",
    full_cmd,
  }, { detach = true })
end

-- Unified Configuration Entry Point
M.config = function()
  -- LSP Setup
  require("lspconfig").clangd.setup(M.lsp.clangd)

  -- Auto-compile Setup
  vim.api.nvim_create_autocmd("BufWritePost", {
    pattern = { "*.c", "*.cpp" },
    callback = compile_and_run,
  })

  -- Existing deferred configurations
  vim.defer_fn(function()
    require("custom.configs.clang-format").setup()
    require("custom.configs.dap").setup()
  end, 100)
end

return M
