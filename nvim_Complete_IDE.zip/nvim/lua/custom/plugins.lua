local plugins = {

  { "augmentcode/augment.vim" },

  {
    "neoclide/coc.nvim",
    branch = "master",
    build = "yarn install --frozen-lockfile",
    config = function()
      -- Your existing COC configuration
      vim.opt.backup = false
      vim.opt.writebackup = false
      -- ... (rest of your config)
    end,
  },
  -- Your other plugins...

  {
    "lewis6991/hover.nvim",
    config = function()
      require("hover").setup {
        init = function()
          -- Enable the LSP provider for C/C++ hover
          require "hover.providers.lsp"
        end,
        preview_opts = {
          border = "single",
        },
        -- Enable mouse hover support
        mouse_providers = { "LSP" },
        -- Set delay for mouse hover (in milliseconds)
        mouse_delay = 1000,
      }

      -- Setup keymaps
      vim.keymap.set("n", "K", require("hover").hover, { desc = "hover.nvim" })

      -- Enable mouse support
      vim.keymap.set("n", "<MouseMove>", require("hover").hover_mouse, { desc = "hover.nvim (mouse)" })
      vim.o.mousemoveevent = true
    end,
  },

  {
    "CopilotC-Nvim/CopilotChat.nvim",
    branch = "main",
    cmd = "CopilotChat",
    dependencies = {
      "github/copilot.vim", -- Make sure the base Copilot plugin is installed
      "nvim-lua/plenary.nvim",
    },
    opts = function()
      local user = vim.env.USER or "User"
      user = user:sub(1, 1):upper() .. user:sub(2)
      return {
        auto_insert_mode = true,
        question_header = " " .. user .. " ",
        answer_header = " Copilot ",
        window = {
          width = 0.4,
        },
      }
    end,
    keys = {
      { "<c-s>", "<CR>", ft = "copilot-chat", desc = "Submit Prompt", remap = true },
      { "<leader>a", "", desc = "+ai", mode = { "n", "v" } },
      {
        "<leader>aa",
        function()
          return require("CopilotChat").toggle()
        end,
        desc = "Toggle (CopilotChat)",
        mode = { "n", "v" },
      },
      {
        "<leader>ax",
        function()
          return require("CopilotChat").reset()
        end,
        desc = "Clear (CopilotChat)",
        mode = { "n", "v" },
      },
      {
        "<leader>aq",
        function()
          vim.ui.input({
            prompt = "Quick Chat: ",
          }, function(input)
            if input ~= "" then
              require("CopilotChat").ask(input)
            end
          end)
        end,
        desc = "Quick Chat (CopilotChat)",
        mode = { "n", "v" },
      },
    },
    config = function(_, opts)
      local chat = require "CopilotChat"
      vim.api.nvim_create_autocmd("BufEnter", {
        pattern = "copilot-chat",
        callback = function()
          vim.opt_local.relativenumber = false
          vim.opt_local.number = false
        end,
      })
      chat.setup(opts)
    end,
  },

  {
    "github/copilot.vim",
    event = "InsertEnter",
    config = function()
      -- Set copilot options (optional)
      vim.g.copilot_no_tab_map = true
      vim.g.copilot_assume_mapped = true
    end,
  },

  -- GitHub Copilot
  {
    "zbirenbaum/copilot.lua",
    lazy = false,
    dependencies = {
      "zbirenbaum/copilot-cmp",
    },
    config = function()
      require("copilot").setup {
        suggestion = { enabled = false },
        panel = { enabled = false },
        filetypes = {
          markdown = true,
          help = true,
        },
      }

      require("copilot_cmp").setup()
    end,
  },

  {
    "ray-x/lsp_signature.nvim",
    event = "LspAttach",
    config = function()
      require("lsp_signature").setup {
        bind = true,
        hint_enable = true,
        handler_opts = {
          border = "rounded",
        },
        floating_window = true,
        floating_window_above_cur_line = true,
        hint_prefix = " ",
        zindex = 50,
        transparency = 10,
      }
    end,
  },

  {
    "lvimuser/lsp-inlayhints.nvim",
    event = "LspAttach",
    config = function()
      require("lsp-inlayhints").setup {
        inlay_hints = {
          parameter_hints = {
            show = true,
            prefix = "← ",
            separator = ", ",
            remove_colon_start = true,
            remove_colon_end = false,
          },
          type_hints = {
            show = true,
            prefix = "» ",
            separator = ", ",
            remove_colon_start = false,
            remove_colon_end = true,
          },
        },
        highlight = "Comment", -- 📝 Ghost-text style (gray/italic)
      }

      -- Attach inlay hints automatically
      vim.api.nvim_create_autocmd("LspAttach", {
        callback = function(args)
          local client = vim.lsp.get_client_by_id(args.data.client_id)
          require("lsp-inlayhints").on_attach(client, args.buf)
        end,
      })
    end,
  },

  {
    "nvimdev/lspsaga.nvim",
    event = "LspAttach",
    dependencies = {
      "nvim-treesitter/nvim-treesitter",
      "nvim-tree/nvim-web-devicons",
    },
    config = function()
      require("lspsaga").setup {
        lightbulb = {
          enable = false, -- disable lightbulb if you want minimal UI
        },
        ui = {
          border = "rounded",
          title = true,
          winblend = 0,
        },
      }
    end,
  },

  {
    "mfussenegger/nvim-dap",
    config = function(_, _)
      require("core.utils").load_mappings "dap"
    end,
  },

  {
    "rcarriga/nvim-dap-ui",
    event = "VeryLazy",
    dependencies = "mfussenegger/nvim-dap",
    config = function()
      local dap = require "dap"
      local dapui = require "dapui"
      dapui.setup()
      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui_config"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui_config"] = function()
        dapui.close()
      end
    end,
  },

  {
    "jay-babu/mason-nvim-dap.nvim",
    event = "VeryLazy",
    dependencies = {
      "williamboman/mason.nvim",
      "mfussenegger/nvim-dap",
    },
    opts = {
      ensure_installed = {
        "codelldb", -- Rust
        "delve", -- Go
        "java-debug-adapter", -- Java
        "debugpy", -- Python
      },
      handlers = {},
    },
  },

  {
    "rcarriga/nvim-dap-ui",
    event = "VeryLazy",
    dependencies = "mfussenegger/nvim-dap",
    config = function()
      local dap = require "dap"
      local dapui = require "dapui"
      dapui.setup()
      dap.listeners.after.event_initialized["dapui_config"] = function()
        dapui.open()
      end
      dap.listeners.before.event_terminated["dapui_config"] = function()
        dapui.close()
      end
      dap.listeners.before.event_exited["dapui_config"] = function()
        dapui.close()
      end
    end,
  },

  { "mhartington/formatter.nvim" },

  {
    "jay-babu/mason-nvim-dap.nvim",
    event = "VeryLazy",
    dependencies = {
      "williamboman/mason.nvim",
      "mfussenegger/nvim-dap",
    },
    opts = {
      handlers = {},
    },
  },
  {
    "saecki/crates.nvim",
    dependencies = "hrsh7th/nvim-cmp",
    ft = { "rust", "toml" },
    config = function(_, opts)
      local crates = require "crates"
      crates.setup(opts)
      crates.show()
    end,
  },
  {
    "hrsh7th/nvim-cmp",
    opts = function()
      local M = require "plugins.configs.cmp"
      table.insert(M.sources, { name = "crates" })
      return M
    end,
  },
  {
    "mfussenegger/nvim-dap",
    config = function(_, _)
      require("core.utils").load_mappings "dap"
    end,
  },
  {
    "jose-elias-alvarez/null-ls.nvim",
    event = "VeryLazy",
    opts = function()
      return require "custom.configs.null-ls"
    end,
  },
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "plugins.configs.lspconfig"
      require "custom.configs.lspconfig"
    end,
  },
  {
    "rust-lang/rust.vim",
    ft = "rust",
    init = function()
      vim.g.rustfmt_autosave = 1
    end,
  },
  {
    "simrat39/rust-tools.nvim",
    ft = "rust",
    dependencies = "neovim/nvim-lspconfig",
    opts = function()
      require "custom.configs.rust-tools"
    end,
    config = function(_, opts)
      require("rust-tools").setup(opts)
    end,
  },
  {
    "williamboman/mason.nvim",
    opts = {
      ensure_installed = {
        "clangd",
        "clang-format",
        "codelldb",
        "rust-analyzer",
        "prettierd",
        "google-java-format",
        "pyright",
        "gopls",
        "codelldb",
        "delve",
        "debugpy",
        "java-debug-adapter",
        "codelldb",
      },
    },
  },
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "plugins.configs.lspconfig"
      require "custom.configs.lspconfig"
    end,
  },

  {
    "stevearc/conform.nvim",
    event = { "BufWritePre" },
    config = function()
      require("conform").setup {
        format_on_save = function(bufnr)
          local ft = vim.bo[bufnr].filetype
          return {
            timeout_ms = 1000,
            -- Apply LSP-based fallback for Rust, and use conform for other filetypes
            lsp_fallback = ft == "rust",
          }
        end,
        formatters_by_ft = {
          lua = { "stylua" },
          python = { "isort", "black" },
          rust = { "rustfmt" },
          javascript = { { "prettierd", "prettier" } },
          c = { "clang_format" }, -- Use clang-format for C files
          cpp = { "clang_format" }, -- Use clang-format for C++ files
        },
        formatters = {
          rustfmt = {
            command = "rustfmt",
            args = { "--edition", "2021" },
            stdin = true,
          },
          clang_format = {
            command = "clang-format", -- Uses installed clang-format (via Mason or system)
            args = { "--style=file" }, -- Uses .clang-format if available, else defaults
            stdin = true, -- Pass content via stdin for better integration
          },
        },
      }
    end,
  },

  -- 🌲 Show current function/class context at top of window
  {
    "nvim-treesitter/nvim-treesitter-context",
    event = "BufReadPost",
    config = function()
      require("treesitter-context").setup {
        enable = true,
        max_lines = 3,
        mode = "cursor", -- or 'topline'
      }
    end,
  },

  -- 🧩 Full Mini.nvim suite
  {
    "echasnovski/mini.nvim",
    version = "*",
    config = function()
      require("mini.pairs").setup()
      require("mini.surround").setup()
      require("mini.comment").setup()
      require("mini.bufremove").setup()
      require("mini.indentscope").setup {
        symbol = "│",
        options = { try_as_border = true },
      }
      require("mini.jump").setup()
      require("mini.statusline").setup()
      require("mini.trailspace").setup()
      require("mini.clue").setup {
        triggers = {
          { mode = "n", keys = "<Leader>" },
          { mode = "x", keys = "<Leader>" },
        },
        clues = require("mini.clue").gen_clues.builtin_show(),
        window = {
          config = {
            width = 40,
          },
        },
      }
    end,
  },

  {
    "echasnovski/mini.nvim",
    version = "*",
    config = function()
      require("mini.pairs").setup()
      require("mini.surround").setup()
      require("mini.comment").setup()
      require("mini.bufremove").setup()
      require("mini.indentscope").setup { symbol = "│" }
      require("mini.jump").setup()
      require("mini.jump2d").setup()
      require("mini.statusline").setup()
      require("mini.trailspace").setup()
      require("mini.clue").setup {
        triggers = {
          { mode = "n", keys = "<Leader>" },
          { mode = "x", keys = "<Leader>" },
        },
        clues = require("mini.clue").gen_clues.builtin_show(),
      }
      require("mini.files").setup()
    end,
  },

  -- Highlight yanked text with bright color
  {
    "nvim-lua/plenary.nvim", -- harmless, used just to anchor the config
    lazy = false,
    config = function()
      vim.api.nvim_create_autocmd("TextYankPost", {
        pattern = "*",
        callback = function()
          vim.highlight.on_yank {
            higroup = "Visual", -- or use a custom highlight group
            timeout = 150,
          }
        end,
      })
    end,
  },

  { -- This plugin
    "Zeioth/compiler.nvim",
    cmd = { "CompilerOpen", "CompilerToggleResults", "CompilerRedo" },
    dependencies = { "stevearc/overseer.nvim", "nvim-telescope/telescope.nvim" },
    opts = {},
  },
  { -- The task runner we use
    "stevearc/overseer.nvim",
    commit = "6271cab7ccc4ca840faa93f54440ffae3a3918bd",
    cmd = { "CompilerOpen", "CompilerToggleResults", "CompilerRedo" },
    opts = {
      task_list = {
        direction = "bottom",
        min_height = 25,
        max_height = 25,
        default_detail = 1,
      },
    },
  },

  {
    "nvim-neotest/neotest",
    dependencies = {
      "nvim-lua/plenary.nvim",
      "nvim-treesitter/nvim-treesitter",
      "antoinemadec/FixCursorHold.nvim",
      "nvim-neotest/neotest-python",
      "rouge8/neotest-rust",
    },
    config = function()
      require("neotest").setup {
        adapters = {
          require "neotest-python",
          require "neotest-rust",
        },
      }
    end,
  },

  -- Or with configuration
  {
    "projekt0n/github-nvim-theme",
    name = "github-theme",
    lazy = false, -- make sure we load this during startup if it is your main colorscheme
    priority = 1000, -- make sure to load this before all the other start plugins
    config = function()
      require("github-theme").setup {
        -- ...
      }

      vim.cmd "colorscheme github_dark"
    end,
  },

  {
    "jay-babu/mason-nvim-dap.nvim",
    opts = {
      ensure_installed = { "codelldb" }, -- C++ debugger
    },
  },

  -- Configure clangd LSP
  {
    "neovim/nvim-lspconfig",
    config = function()
      require "plugins.configs.lspconfig" -- Load default LSP configurations from NvChad
      require("lspconfig").clangd.setup {
        cmd = { "clangd", "--background-index", "--clang-tidy", "--completion-style=detailed" },
        filetypes = { "c", "cpp", "objc", "objcpp" },
        root_dir = require("lspconfig.util").root_pattern("compile_commands.json", ".git"),
        capabilities = require("plugins.configs.lspconfig").capabilities,
        on_attach = function(client, bufnr)
          -- Keymaps for LSP functions
          local opts = { noremap = true, silent = true, buffer = bufnr }
          vim.keymap.set("n", "gd", vim.lsp.buf.definition, opts)
          vim.keymap.set("n", "gr", vim.lsp.buf.references, opts)
          vim.keymap.set("n", "K", vim.lsp.buf.hover, opts)
          vim.keymap.set("n", "<leader>rn", vim.lsp.buf.rename, opts)
        end,
      }
    end,
  },
}

return plugins
