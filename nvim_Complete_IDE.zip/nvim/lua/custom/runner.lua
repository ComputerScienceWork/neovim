-- ~/.config/nvim/lua/custom/runner.lua
local M = {}

local wezterm_path = "/opt/homebrew/bin/wezterm"

-- 💾 Unified runner with C/C++ support and safety checks
M.run_current_file = function()
  vim.cmd "w" -- Initial save

  local file = vim.api.nvim_buf_get_name(0)
  local filename = vim.fn.fnamemodify(file, ":t")
  local cwd = vim.fn.fnamemodify(file, ":h")
  local ft = vim.bo.filetype
  local cmd = ""
  local log_path = "/tmp/runner_last.log"

  -- Validate WezTerm installation
  if vim.fn.executable(wezterm_path) == 0 then
    vim.notify("❌ WezTerm executable missing: " .. wezterm_path, vim.log.levels.ERROR)
    return
  end

  -- Auto-format C/C++ files with error handling
  if ft == "c" or ft == "cpp" then
    local ok, err = pcall(function()
      vim.cmd "%!clang-format"
      vim.cmd "w" -- Save formatted version
    end)
    if not ok then
      vim.notify("❌ Formatting failed: " .. tostring(err), vim.log.levels.ERROR)
      return
    end
  end

  -- Command definitions with enhanced security
  if ft == "python" then
    cmd = "python3 " .. vim.fn.shellescape(filename)
  elseif ft == "lua" then
    cmd = "lua " .. vim.fn.shellescape(filename)
  elseif ft == "sh" then
    cmd = "zsh " .. vim.fn.shellescape(filename)
  elseif ft == "rust" then
    cmd = "cargo run"
  elseif ft == "go" then
    cmd = "go run " .. vim.fn.shellescape(filename)
  elseif ft == "javascript" then
    cmd = "node " .. vim.fn.shellescape(filename)
  elseif ft == "c" then
    local output = "/tmp/" .. vim.fn.fnamemodify(filename, ":r")
    cmd = string.format(
      "xcrun clang -g -Wall -Wextra -Werror -pedantic -O0 -std=c17 -fstack-protector-all -fsanitize=undefined -o %s %s && %s; rm -f %s",
      vim.fn.shellescape(output),
      vim.fn.shellescape(filename),
      vim.fn.shellescape(output),
      vim.fn.shellescape(output)
    )
  elseif ft == "cpp" then
    local output = "/tmp/" .. vim.fn.fnamemodify(filename, ":r")
    cmd = string.format(
      "xcrun clang++ -g -Wall -Wextra -Werror -pedantic -O0 -std=c++20 -fstack-protector-all -fsanitize=undefined -o %s %s && %s; rm -f %s",
      vim.fn.shellescape(output),
      vim.fn.shellescape(filename),
      vim.fn.shellescape(output),
      vim.fn.shellescape(output)
    )
  else
    vim.notify("❌ Unsupported filetype: " .. ft, vim.log.levels.WARN)
    return
  end

  -- Execution template with safety guards
  local final_cmd = string.format(
    [[
    set -euo pipefail
    cd -- %s
    {
      echo '\033[1;33m==============================\033[0m'
      echo '\033[1;36m🧠 File   :\033[0m %s'
      echo '\033[1;36m📂 CWD    :\033[0m %s'
      echo '\033[1;36m📜 Lang   :\033[0m %s'
      echo '\033[1;36m🚀 Command:\033[0m %s'
      echo '\033[1;33m==============================\033[0m'
      echo '\033[1;32m▶️ Running...\033[0m'
      echo "" > %s
      (%s) 2>&1 | tee %s
      STATUS=$?
      echo '\033[1;33m==============================\033[0m'
      if [ $STATUS -eq 0 ]; then
        echo '\033[1;32m✔ Success!\033[0m'
      else
        echo '\033[1;31m✖ Failed (exit code $STATUS)\033[0m'
      fi
      echo '\033[1;33m==============================\033[0m'
      echo '\033[1;90mSaved output: %s\033[0m'
      read -n 1 -s -p $'Press any key to close...'
    } </dev/tty >/dev/tty
    ]],
    vim.fn.shellescape(cwd),
    vim.fn.shellescape(filename),
    vim.fn.shellescape(cwd),
    vim.fn.shellescape(ft),
    cmd,
    vim.fn.shellescape(log_path),
    cmd,
    vim.fn.shellescape(log_path),
    vim.fn.shellescape(log_path)
  )

  vim.fn.jobstart({
    wezterm_path,
    "start",
    "--always-new-process",
    "zsh",
    "-c",
    final_cmd,
  }, { detach = true })
end

return M
