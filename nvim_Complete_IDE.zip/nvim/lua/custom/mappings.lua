local M = {}

M.dap = {
  plugin = true,
  n = {
    ["<leader>db"] = {
      "<cmd> DapToggleBreakpoint <CR>",
      "Add breakpoint at line",
    },
    ["<leader>dr"] = {
      "<cmd> DapContinue <CR>",
      "Start or continue the debugger",
    },
    ["<leader>dus"] = {
      function()
        local widgets = require "dap.ui.widgets"
        local sidebar = widgets.sidebar(widgets.scopes)
        sidebar.open()
      end,
      "Open debugging sidebar",
    },
  },
}

M.crates = {
  n = {
    ["<leader>rcu"] = {
      function()
        require("crates").upgrade_all_crates()
      end,
      "Upgrade all crates",
    },
  },
}

M.mini = {
  plugin = true,
  n = {
    ["<leader>m"] = { name = "Mini.nvim 🔧" },

    ["<leader>mt"] = {
      "<cmd>TSContextToggle<CR>",
      "Toggle context line",
    },

    ["<leader>mw"] = {
      "<cmd>lua MiniTrailspace.trim()<CR>",
      "Trim trailing whitespace",
    },

    ["<leader>mb"] = {
      function()
        require("mini.bufremove").delete(0, false)
      end,
      "Smart buffer delete",
    },

    ["<leader>mf"] = {
      function()
        require("mini.files").open(vim.api.nvim_buf_get_name(0))
      end,
      "Open mini.files",
    },

    ["<leader>mj"] = {
      function()
        require("mini.jump2d").start {}
      end,
      "Start jump2d",
    },
  },
}

M.lsp_saga = {
  plugin = true,
  n = {
    ["K"] = {
      "<cmd>Lspsaga hover_doc<CR>",
      "LSP Hover Documentation",
    },
    ["<leader>ca"] = {
      "<cmd>Lspsaga code_action<CR>",
      "Code Action",
    },
    ["gd"] = {
      "<cmd>Lspsaga goto_definition<CR>",
      "Go to Definition",
    },
    ["gr"] = {
      "<cmd>Lspsaga finder<CR>",
      "LSP References/Definitions",
    },
  },
}

vim.api.nvim_set_keymap(
  "n",
  "<leader>r",
  ":w<CR>:lua require('plugins.lspconfig').run_c_cpp_on_save()<CR>",
  { noremap = true, silent = true }
)

M.runner = {
  plugin = true,
  n = {
    ["<leader>rr"] = {
      function()
        local file = vim.fn.expand "%:p"
        local ft = vim.bo.filetype
        local cwd = vim.fn.fnamemodify(file, ":h")
        local autocmd = require "custom.autocmds"
        vim.notify "🔁 Manually running current file..."
        vim.cmd "write"
      end,
      "Manual code run 🧪",
    },
  },
}

M.general = {
  n = {
    ["<leader>rr"] = {
      function()
        require("custom.autocmd").run_current_file()
      end,
      "󰩈  Run current file",
    },
    ["<leader>td"] = {
      function()
        require("custom.autocmd").toggle_debug_mode()
      end,
      "Toggle debug mode",
    },
  },
}

-- In your mappings.lua
M.general = {
  n = {
    ["<leader>db"] = {
      function()
        require("dap").toggle_breakpoint()
      end,
      "Toggle breakpoint",
    },
  },
}

-- In your mappings.lua
M.general = {
  n = {
    ["<leader>dc"] = {
      function()
        require("dap").continue()
      end,
      "Start/Continue debugging",
    },
    ["<leader>di"] = {
      function()
        require("dap").step_into()
      end,
      "Step into",
    },
    ["<leader>do"] = {
      function()
        require("dap").step_out()
      end,
      "Step out",
    },
    ["<leader>dn"] = {
      function()
        require("dap").step_over()
      end,
      "Step over",
    },
    ["<leader>dr"] = {
      function()
        require("dap").repl.open()
      end,
      "Open REPL",
    },
    ["<leader>de"] = {
      function()
        require("dap").terminate()
      end,
      "End debugging",
    },
  },
}

-- In your autocmd.lua
vim.api.nvim_create_autocmd("FileType", {
  pattern = "dap-repl",
  callback = function()
    require("dapui").open()
  end,
})

vim.api.nvim_create_autocmd("User", {
  pattern = "DapStopped",
  callback = function()
    require("dapui").open()
  end,
})

vim.api.nvim_create_autocmd("User", {
  pattern = "DapTerminated",
  callback = function()
    require("dapui").close()
  end,
})

vim.keymap.set("n", "<leader>cc", ":w | !clang % -o %< && ./%< <CR>", { noremap = true, silent = true })
vim.keymap.set("n", "<leader>cC", ":w | !clang++ % -o %< && ./%< <CR>", { noremap = true, silent = true })

M.copilot = {
  n = {
    ["<leader>cp"] = { "<cmd>Copilot panel<CR>", "Copilot Panel" },
  },
  i = {
    ["<C-l>"] = {
      function()
        vim.fn.feedkeys(vim.fn["copilot#Accept"](), "")
      end,
      "Copilot Accept",
      { replace_keycodes = true, nowait = true, silent = true, expr = true, noremap = true },
    },
  },
}

M.copilot = {
  i = {
    ["<C-l>"] = {
      function()
        vim.fn.feedkeys(vim.fn["copilot#Accept"](), "")
      end,
      "Copilot Accept",
      { noremap = true, silent = true },
    },
  },
}

M.hover = {
  n = {
    ["<leader>hh"] = {
      function()
        require("hover").hover()
      end,
      "Show hover information",
    },
    ["<leader>hs"] = {
      function()
        require("hover").hover_select()
      end,
      "Select hover source",
    },
  },
}

return M
