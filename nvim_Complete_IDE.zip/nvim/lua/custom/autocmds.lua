local M = {}

local wezterm_path = "/opt/homebrew/bin/wezterm"
local debug_mode = false

-- 💾 Unified run function with C/C++ support and debug toggle
M.run_current_file = function()
  vim.cmd "w" -- Save file

  local file = vim.api.nvim_buf_get_name(0)
  local filename = vim.fn.fnamemodify(file, ":t")
  local cwd = vim.fn.fnamemodify(file, ":h")
  local ft = vim.bo.filetype
  local cmd = ""
  local log_path = "/tmp/runner_last.log"

  -- Verify WezTerm path
  if vim.fn.filereadable(wezterm_path) == 0 then
    vim.notify("❌ WezTerm not found at path: " .. wezterm_path, vim.log.levels.ERROR)
    return
  end

  -- Auto-format for C/C++ with error handling
  if ft == "c" or ft == "cpp" then
    local ok, err = pcall(function()
      vim.cmd "%!clang-format --style=file"
      vim.cmd "w" -- Save after formatting
    end)
    if not ok then
      vim.notify("❌ clang-format failed: " .. tostring(err), vim.log.levels.ERROR)
      return
    end
  end

  -- Command logic to compile and run files based on their filetype
  if ft == "python" then
    cmd = "python3 " .. vim.fn.shellescape(filename)
  elseif ft == "lua" then
    cmd = "lua " .. vim.fn.shellescape(filename)
  elseif ft == "sh" then
    cmd = "zsh " .. vim.fn.shellescape(filename)
  elseif ft == "rust" then
    cmd = "cargo run"
  elseif ft == "go" then
    cmd = "go run " .. vim.fn.shellescape(filename)
  elseif ft == "javascript" then
    cmd = "node " .. vim.fn.shellescape(filename)
  elseif ft == "c" or ft == "cpp" then
    local output = "/tmp/" .. vim.fn.fnamemodify(filename, ":r")
    local compile_cmd = string.format(
      "xcrun clang -g -Wall -Wextra -Werror -pedantic -O0 -std=c17 -fstack-protector-all -fsanitize=undefined -o %s %s",
      vim.fn.shellescape(output),
      vim.fn.shellescape(filename)
    )
    if ft == "cpp" then
      compile_cmd = string.format(
        "xcrun clang++ -g -Wall -Wextra -Werror -pedantic -O0 -std=c++20 -fstack-protector-all -fsanitize=undefined -o %s %s",
        vim.fn.shellescape(output),
        vim.fn.shellescape(filename)
      )
    end

    if debug_mode then
      -- Debug mode: Compile with debug symbols and start debugging
      local dap = require "dap"
      dap.run {
        type = "lldb",
        request = "launch",
        name = "Debug",
        program = output,
        cwd = cwd,
        stopOnEntry = true,
      }
    else
      -- Normal mode: Compile and run
      cmd = compile_cmd .. " && " .. vim.fn.shellescape(output) .. "; rm -f " .. vim.fn.shellescape(output)
    end
  else
    vim.notify("❌ Unsupported filetype: " .. ft, vim.log.levels.WARN)
    return
  end

  if cmd == "" then
    vim.notify("❌ No command set for filetype: " .. ft, vim.log.levels.ERROR)
    return
  end

  -- Prepare and execute the final shell command
  local final_cmd = string.format(
    [[
      cd %s
      echo '\033[1;33m==============================\033[0m'
      echo '\033[1;36m🧠 File   :\033[0m %s'
      echo '\033[1;36m📂 CWD    :\033[0m %s'
      echo '\033[1;36m📜 Lang   :\033[0m %s'
      echo '\033[1;36m🚀 Cmd    :\033[0m %s'
      echo '\033[1;33m==============================\033[0m'
      echo '\033[1;32m▶️ Running...\033[0m'
      echo "" > %s
      zsh -c '%s' 2>&1 | tee %s
      STATUS=$?
      echo '\033[1;33m==============================\033[0m'
      if [ $STATUS -eq 0 ]; then
        echo '\033[1;32m✔ Success\033[0m'
      else
        echo '\033[1;31m✖ Failed (exit code $STATUS)\033[0m'
      fi
      echo '\033[1;33m==============================\033[0m'
      echo '\033[1;90mOutput saved to: %s\033[0m'
      read -n 1 -s -p $'Press any key to close...'
    ]],
    cwd,
    filename,
    cwd,
    ft,
    cmd,
    log_path,
    cmd,
    log_path,
    log_path
  )

  -- Run the final command in WezTerm
  if not debug_mode then
    vim.fn.jobstart({
      wezterm_path,
      "start",
      "--always-new-process",
      "zsh",
      "-c",
      final_cmd,
    }, { detach = true })
  end
end

-- ✅ Enhanced auto-run with C/C++ support and debug toggle
vim.api.nvim_create_autocmd("BufWritePost", {
  callback = function()
    local ft = vim.bo.filetype
    local supported = {
      rust = true,
      lua = true,
      python = true,
      sh = true,
      go = true,
      javascript = true,
      c = true,
      cpp = true,
    }

    if supported[ft] then
      M.run_current_file()
    end
  end,
})

-- Toggle debug mode
M.toggle_debug_mode = function()
  debug_mode = not debug_mode
  vim.notify("Debug mode " .. (debug_mode and "enabled" or "disabled"), vim.log.levels.INFO)
end

return M
